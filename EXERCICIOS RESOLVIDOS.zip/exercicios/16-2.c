// ALUNO TELLES QUE FEZ. :D 

#include <stdio.h>
#include <stdlib.h>
q2()
{
for (int i=0;i<=9;i++)
{
printf("O Meu Nome e Telles");
}
}

main()
{
int k;
scanf("%d",&k);
switch(k) {
case 2:
q2();
break;
}
}