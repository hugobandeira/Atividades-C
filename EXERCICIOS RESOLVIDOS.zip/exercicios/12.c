#include<stdio.h>

int main () {

int j;
int l;

	printf("Coloque um valor: ");
	scanf("%d",&j);

	l = 1000 * j;

	printf("\nValor em L: %d\n",l);

}

