#include <stdio.h>

main () {

char nome[40];
char end[100];
char tel[10];

	puts("Nome:");
	gets(nome);

	puts("Endereco:");
	gets(end);

	puts("Telefone :D:");
	gets(tel);

	puts ("Nome digitado:");
	puts(nome);

	puts ("Endereco digitado:");
	puts(end);

	puts ("Telefone digitado:");
	puts(tel);

}

