#include<stdio.h>

int main () {

int a;
int v;
int r;
int aux;
int pi = 3.141592;

	printf("Coloque Altura: ");
	scanf("%d",&a);
	printf("Coloque Raio: ");
	scanf("%d",&r);

	v = pi * (r*r) * a;

	printf("\nValor do VOLUME: %d\n",v);

}


