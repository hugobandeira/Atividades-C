//Jackson Hugo que fez 

#include <stdio.h>
int main (){
atv3();
}

atv3 () {

char n[20],e[20],r[20];
puts("digite, nome,endereço, e telefone");
gets(n);
gets(e);
gets(r);

puts(n);
puts(e);
puts(r);
}