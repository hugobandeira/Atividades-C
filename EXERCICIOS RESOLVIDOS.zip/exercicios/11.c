#include<stdio.h>

int main () {

int vet[20];
int j;

	for ( j = 10; j <= 21 ; j++) {
		vet[j]=j;
		printf("\n%d",vet[j]);
			}

}
