// NOME DO ALUNO: JOAO DE DEUS

//Preencher um vetor com os numeros pares do número 2 a 20, 
// USANDO PROCEDIMENTO

#include<stdio.h>
int main () {
	
int q_4();
}
int q_4(){
	
int vetor[20];

for(int i=2;i<=20; i=i+2 )
vetor[i]=i;
}
