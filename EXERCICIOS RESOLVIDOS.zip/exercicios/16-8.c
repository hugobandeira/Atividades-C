// NOME DO ALUNO: gabriel santos carvalho

//Preencher um vetor com 6 numeros e mostra-los na tela.

#include <stdio.h>

int main(){
	 
que8();

}

int que8(){
	
	int vetor [6]={1,2,3,4,5,6};
	int i;
	
	for(i=0;i<6;i++){
	
	printf("\n%d",vetor[i]);
			
					} 
}

