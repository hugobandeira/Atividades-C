#include <stdio.h>
#include <strings.h>

struct base1 {
	int num1;
};

struct base2 {
	int num2;
};

struct base1 pegar1;
struct base2 pegar2;

int main () {
	
	printf("Numero 1:");
	scanf("%d",&pegar1.num1);

	printf("Numero 2:");
	scanf("%d",&pegar2.num2);
	
	int soma;
	
	soma = pegar1.num1+pegar2.num2;
	
printf("\n Resultado: %d \n",soma);		

}

