#include <stdio.h>
#include <strings.h>

struct base {
		float primeiro;
		float segundo;
		float quantia;
		float resto;
};

struct base pegar;

int main () {
	
	pegar.quantia = 780.000;	
	
	pegar.primeiro = (pegar.quantia*46)/100;

	pegar.segundo = (pegar.quantia*32)/100;

	pegar.resto = pegar.quantia - (pegar.primeiro+pegar.segundo);
	
	printf ("\n %f \n",pegar.primeiro);
	printf ("\n %f \n",pegar.segundo);
	printf ("\n %f \n",pegar.resto);

}

